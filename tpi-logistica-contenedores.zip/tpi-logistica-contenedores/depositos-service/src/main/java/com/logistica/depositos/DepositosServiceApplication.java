package com.logistica.depositos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DepositosServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(DepositosServiceApplication.class, args);
    }
}
