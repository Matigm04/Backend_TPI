package com.logistica.camiones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CamionesServiceApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(CamionesServiceApplication.class, args);
    }
}
