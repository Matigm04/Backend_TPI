package com.logistica.tarifas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TarifasServiceApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(TarifasServiceApplication.class, args);
    }
}
