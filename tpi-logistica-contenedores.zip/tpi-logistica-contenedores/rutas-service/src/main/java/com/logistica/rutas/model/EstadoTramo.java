package com.logistica.rutas.model;

public enum EstadoTramo {
    ESTIMADO,
    ASIGNADO,
    INICIADO,
    FINALIZADO
}
