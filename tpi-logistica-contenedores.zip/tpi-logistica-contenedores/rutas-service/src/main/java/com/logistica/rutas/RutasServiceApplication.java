package com.logistica.rutas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RutasServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(RutasServiceApplication.class, args);
    }

}