package com.logistica.rutas.model;

public enum TipoTramo {
    ORIGEN_DEPOSITO,
    DEPOSITO_DEPOSITO,
    DEPOSITO_DESTINO,
    ORIGEN_DESTINO
}
