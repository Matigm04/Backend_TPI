package com.logistica.rutas.exception;

public class RutaNotFoundException extends RuntimeException {
    public RutaNotFoundException(String message) {
        super(message);
    }
}
