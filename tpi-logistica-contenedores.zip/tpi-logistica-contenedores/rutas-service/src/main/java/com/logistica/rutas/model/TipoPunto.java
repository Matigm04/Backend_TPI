package com.logistica.rutas.model;

public enum TipoPunto {
    ORIGEN,
    DEPOSITO,
    DESTINO
}
