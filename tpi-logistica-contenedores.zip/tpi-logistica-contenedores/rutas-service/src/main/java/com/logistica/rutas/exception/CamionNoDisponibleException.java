package com.logistica.rutas.exception;

public class CamionNoDisponibleException extends RuntimeException {
    public CamionNoDisponibleException(String message) {
        super(message);
    }
}
