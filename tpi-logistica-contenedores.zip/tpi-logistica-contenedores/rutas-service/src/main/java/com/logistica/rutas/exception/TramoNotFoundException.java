package com.logistica.rutas.exception;

public class TramoNotFoundException extends RuntimeException {
    public TramoNotFoundException(String message) {
        super(message);
    }
}
