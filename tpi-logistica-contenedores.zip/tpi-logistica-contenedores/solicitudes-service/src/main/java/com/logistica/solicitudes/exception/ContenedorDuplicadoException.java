package com.logistica.solicitudes.exception;

public class ContenedorDuplicadoException extends RuntimeException {
    public ContenedorDuplicadoException(String message) {
        super(message);
    }
}
