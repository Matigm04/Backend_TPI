package com.logistica.solicitudes.model;

public enum EstadoSolicitud {
    BORRADOR,
    PROGRAMADA,
    EN_TRANSITO,
    ENTREGADA,
    CANCELADA
}
